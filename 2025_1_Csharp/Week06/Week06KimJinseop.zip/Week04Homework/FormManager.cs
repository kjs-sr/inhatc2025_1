﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Week04Homework
{
    public partial class FormManager: Form
    {
        //인스턴스 필드(변수), 멤버 변수
        Department[] departments;
        List<Professor> professors;
        Dictionary<string, Student> students;

        List<Grade> testGrades;
        TextBox[] tbxTestScores;

        //생성자
        //인스턴스 생성시 초기화가 필요한 코드를 넣는다.
        public FormManager()
        {
            InitializeComponent();

            departments = new Department[10];
            professors = new List<Professor>();
            students = new Dictionary<string, Student>();

            for (int i=1; i<=4; i++)
                cmbYear.Items.Add(i);

            cmbClass.Items.AddRange(new object[] { "A", "B", "C" });

            cmbRegStatus.Items.Add("재학");
            cmbRegStatus.Items.Add("졸업");
            cmbRegStatus.Items.Add("휴학");
            cmbRegStatus.Items.Add("퇴학");

            testGrades = new List<Grade>();
            tbxTestScores = new TextBox[]
            {
                tbxTestScore1,
                tbxTestScore2,
                tbxTestScore3,
                tbxTestScore4,
                tbxTestScore5,
                tbxTestScore6,
                tbxTestScore7,
                tbxTestScore8,
                tbxTestScore9,
            };

        }
        private void btnRegisterDepartment_Click(object sender, EventArgs e)
        {
            if(tbxDepartmentCode.Text == "" || tbxDepartmentName.Text == "")
            {
                MessageBox.Show("학과코드 혹은 학과이름을 입력해주세요.");
                return;
            }
            int index = -1;
            for(int i=0; i<departments.Length; i++)
            {
                if (departments[i] == null)
                {
                    if(index < 0)
                        index = i;
                    //break;
                }
                else
                {
                    if (departments[i].Code == tbxDepartmentCode.Text)
                    {
                        //메시지 띄우기
                        MessageBox.Show("이미 존재하는 학과코드 입니다.");
                        return;
                    }
                }
            }
            if (index < 0)
            {
                //메세지 띄우기
                MessageBox.Show("더 이상 학과정보를 등록할 수 없습니다.");
                return;
            }
            Department dept = new Department();
            dept.Code = tbxDepartmentCode.Text;
            dept.Name = tbxDepartmentName.Text;

            departments[index] = dept;
            //추후 아래 3문장은 지운다.
            lbxDepartment.Items.Add(dept);
            //lbxDepartment.Items.Add(dept.Code);
            //lbxDepartment.Items.Add(dept.Name);
            //lbxDepartment.Items.Add($"[{dept.Code}] {dept.Name}");
            tbxDepartmentCode.Text = "";
            tbxDepartmentName.Text = "";
        }

        private void btnRemoveDepartment_Click(object sender, EventArgs e)
        {
            if(lbxDepartment.SelectedIndex < 0)
            {
                //메세지 띄우기
                MessageBox.Show("삭제할 학과를 선택해주세요.");
                return;
            }

            //is 연산자, 타입 확인용으로 사용.
            if(lbxDepartment.SelectedItem is Department)
            {
                var target = (Department)lbxDepartment.SelectedItem;
                
                for(int i=0; i < departments.Length; i++)
                {
                    if (departments[i] != null && departments[i] == target)
                    {
                        departments[i] = null;
                        break;
                    }
                }
                lbxDepartment.Items.RemoveAt(lbxDepartment.SelectedIndex);
                lbxDepartment.SelectedIndex = -1;
            }
        }

        private void tabMain_SelectedIndexChanged(object sender, EventArgs e)
        {
            switch (tabMain.SelectedIndex)
            {
                case 0:
                    break;
                case 1:
                    cmbProfessorDepartment.Items.Clear();
                    foreach (var department in departments)
                    {
                        if (department != null)
                        {
                            cmbProfessorDepartment.Items.Add(department);
                        }
                    }
                    cmbProfessorDepartment.SelectedIndex = -1;
                    lbxProfessor.Items.Clear();
                    break;
                case 2:
                    cmbDepartment.Items.Clear();
                    foreach (var department in departments)
                    {
                        if (department != null)
                        {
                            cmbDepartment.Items.Add(department);
                        }
                    }
                    break;
                default:
                    break;
            }
        }

        private void cmbProfessorDepartment_SelectedIndexChanged(object sender, EventArgs e)
        {
            //index값 검사해서 진행여부 결정
            lbxProfessor.Items.Clear();

            //as 형변환 연산자
            //형변환이 정상적이지 않으면 null반환.
            var department = cmbProfessorDepartment.SelectedItem as Department;

            if(department != null)
            {
                foreach(var professor in professors)
                {
                    if(professor != null && professor.DepartmentCode == department.Code)
                    {
                        lbxProfessor.Items.Add(professor);
                    }
                }
            }
        }

        private void btnRegisterProfessor_Click(object sender, EventArgs e)
        {
            if(cmbProfessorDepartment.SelectedIndex == -1)
            {
                MessageBox.Show("소속학과를 선택해주세요.");
                return;
            }
            if (tbxProfessorNumber.Text == "" || tbxProfessorName.Text == "")
            {
                MessageBox.Show("교수번호 혹은 교수이름을 입력해주세요.");
                return;
            }
            for (int i = 0; i < professors.Count; i++)
            {
                if (professors[i].Number == tbxProfessorNumber.Text)
                {
                    //메시지 띄우기
                    MessageBox.Show("이미 존재하는 교수번호 입니다.");
                    return;
                }
            }

            Professor prof = new Professor();
            var department = cmbProfessorDepartment.SelectedItem as Department;

            prof.DepartmentCode = department.Code;
            prof.Number = tbxProfessorNumber.Text;
            prof.Name = tbxProfessorName.Text;

            professors.Add(prof);
            lbxProfessor.Items.Add(prof);

            tbxProfessorNumber.Text = "";
            tbxProfessorName.Text = "";
        }

        private void btnRemoveProfessor_Click(object sender, EventArgs e)
        {
            if (lbxProfessor.SelectedIndex < 0)
            {
                //메세지 띄우기
                MessageBox.Show("삭제할 교수를 선택해주세요.");
                return;
            }

            //is 연산자, 타입 확인용으로 사용.
            if (lbxProfessor.SelectedItem is Professor)
            {
                var target = (Professor)lbxProfessor.SelectedItem;

                for (int i = 0; i < professors.Count; i++)
                {
                    if (professors[i] != null && professors[i] == target)
                    {
                        professors.Remove(target);
                        break;
                    }
                }
                lbxProfessor.Items.Remove(lbxProfessor.SelectedItem);
                lbxProfessor.SelectedIndex = -1;
            }
        }

        private void cmbDepartment_SelectedIndexChanged(object sender, EventArgs e)
        {
            cmbAdivisor.Items.Clear();

            //as 형변환 연산자
            //형변환이 정상적이지 않으면 null반환.
            var department = cmbProfessorDepartment.SelectedItem as Department;

            if (department != null)
            {
                foreach (var professor in professors)
                {
                    if (professor != null && professor.DepartmentCode == department.Code)
                    {
                        cmbAdivisor.Items.Add(professor);
                    }
                }
            }
        }

        private void btnNew_Click(object sender, EventArgs e)
        {
            tbxNumber.Text = "20";
            tbxBirthYear.Text = "20";
        }

        Student selectedStudent = null;
        private void btnRegister_Click(object sender, EventArgs e)
        {
            if(selectedStudent == null)
            {
                RegisterStudent();
            }
            else
            {
                UpdateStudent();
            }
        }

        private void RegisterStudent()
        {
            var number = tbxNumber.Text.Trim(); //Trim() - 공백제거
            
            if(true == students.ContainsKey(number))
            {
                tbxNumber.Focus();
                return;
            }

            Student student = new Student();
            student.Number = number;
            student.Name = tbxName.Text.Trim();

            int birthYear, birthMonth;//, birthDay;
            if(int.TryParse(tbxBirthYear.Text, out birthYear))
            {

            }
            else
            {
                return;
            }
            if (int.TryParse(tbxBirthMonth.Text, out birthMonth))
            {

            }
            else
            {
                return;
            }
            if (int.TryParse(tbxBirthDay.Text, out int birthDay))
            {

            }
            else
            {
                return;
            }
            //DateTime.Now (현재시간)
            student.BirthInfo = new DateTime(birthYear, birthMonth, birthDay);

            if(cmbDepartment.SelectedIndex < 0)
            {
                //cmbDepartment.Focus();
                //return;
                student.DepartmentCode = null;
            }
            else
            {
                student.DepartmentCode = (cmbDepartment.SelectedItem as Department).Code;
            }

            students[number] = student; //딕셔너리에 데이터 추가방법 1
            //students.Add(number, student); //딕셔너리에 데이터 추가방법 1
            lbxDictionary.Items.Add(student);
        }

        private void UpdateStudent()
        {
            //숙제
            throw new NotImplementedException();
        }

        private void lbxDictionary_SelectedIndexChanged(object sender, EventArgs e)
        {
            btnNew_Click(sender,EventArgs.Empty);

            if (lbxDictionary.SelectedIndex < 0)
                return;

            selectedStudent = (lbxDictionary.SelectedItem as Student);

            if(selectedStudent != null)
            {
                DisplaySelectedStudent(selectedStudent);
            }
        }

        private void DisplaySelectedStudent(Student student)
        {
            tbxNumber.ReadOnly = true;
            tbxName.Text = student.Number;

            tbxBirthYear.Text = student.BirthInfo.Year.ToString();
            tbxBirthMonth.Text = student.BirthInfo.Month.ToString();
            tbxBirthDay.Text = student.BirthInfo.Day.ToString();

            for (int i = 0; i <= departments.Length; i++)
            {
                if (departments[i].Code == student.DepartmentCode)
                {
                    cmbDepartment.SelectedIndex = i;
                    break;
                }
            }
        }

        private void btnTestSearchStudent_Click(object sender, EventArgs e)
        {
            selectedStudent = SearchStudentByNumber(tbxTestNumber.Text);
        }

        private Student SearchStudentByNumber(string number)
        {
            if (students.ContainsKey(number))
            {
                return students[number];
            }
            else
            {
                return null;
            }

        }
    }
}