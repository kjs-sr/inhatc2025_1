﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Week04Homework
{
    class Grade
    {
        public static int MAX_GRADE_COUNT = 9;
        //인스턴스 필드
        public string StudentNumber;
        public List<double> Scores = new List<double>();
    }
}
